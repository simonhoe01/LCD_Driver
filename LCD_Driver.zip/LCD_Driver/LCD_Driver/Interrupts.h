/*
 * Interrupts.cpp
 *
 * Created: 29-04-2024 14:02:28
 *  Author: Geileren
 */ 
#include "UserPanel.h"

UserPanel panelDriver;

//skrue op
ISR(INT4_vect){
	panelDriver.TempUp();
}

//skrue ned
ISR(INT5_vect){
	panelDriver.TempDown();
}