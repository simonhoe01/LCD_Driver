#include "UserPanel.h"
using namespace std;




UserPanel::UserPanel() : master(), targetTemperature(23), buttonPinplus(PE4), buttonPinminus(PE5) {}

void UserPanel::setup() {
	// Initialiserer (I2C) ved hj�lp af den medf�lgende driver
	master.InitI2C();

	

	DDRE &= 0b11001111;

	// Sender nulstil-kommandoen til displayet - dette tvinger mark�ren tilbage til begyndelsen af displayet
	master.SendStart(DISPLAY_ADDRESS1, I2C_WRITE_MODE);
	master.SendByte('|'); // S�tter LCD'en i indstillings-tilstand
	master.SendByte('-'); // Sender kommandoen til at rydde displayet
	master.SendStop(); // Stopper transmissionen over I2C
	
	//Setup til interrupts
	sei(); //aktivere interrupts
	
	//Aktivere ekstern interrupt p� int4 og int5
	EIMSK |= 0b00110000;
	EICRB |= 0b00000000; //rising edge
	
	i2cSendValue(targetTemperature);
}

void UserPanel::TempUp()
{
	upMelody(); // kalder melodi
	targetTemperature++; // incrementerer targertemp
	i2cSendValue(targetTemperature); // sender target temp til display
	_delay_ms(200);
}

void UserPanel::TempDown()
{
	downMelody(); // kalder melodi
	targetTemperature--; // decrementerer targettemp 
	i2cSendValue(targetTemperature);
	_delay_ms(200);
}



void UserPanel::i2cSendValue(int value) {
	char tempStr[20];
	sprintf(tempStr, "Sat temperatur: %d", value);

	// Starter transmission
	master.SendStart(DISPLAY_ADDRESS1, I2C_WRITE_MODE);
	master.SendByte('|'); // S�tter LCD'en i indstillings-tilstand
	master.SendByte('-'); // Sender kommandoen til at rydde displayet

	// Sender temperatur-strengen
	for (int i = 0; tempStr[i] != '\0'; i++) {
		master.SendByte(tempStr[i]);
	}

	// Afslutter transmission
	master.SendStop();
}

void UserPanel::tonePlayer(int toneDelay, uint32_t duration){
	
	// Definerer PG5 som output
	DDRG |= (1 << PG5);
	
	uint32_t tempDuration = duration * 1000;
	for (uint32_t i = 0; i < tempDuration; i += 2 * toneDelay) {
		// S�tter PG5 LOW
		PORTG &= ~(1 << PG5);
		for (int j = 0; j < toneDelay; j++) { // forsinkelse
			asm volatile ("nop"); // G�r ingenting
		}
		
		// S�tter PG5 HIGH
		PORTG |= (1 << PG5);
		for (int j = 0; j < toneDelay; j++) {
			asm volatile ("nop"); // G�r ingenting
		}
	}
	
	_delay_ms(20);
}



void UserPanel::upMelody() // Melodi til at afspille n�r der skrues op for temperaturen
{
	tonePlayer(261, 300);
	
	tonePlayer(294, 300);
	
	tonePlayer(330, 300);
	
	tonePlayer(349, 300);
	
	tonePlayer(392, 300);
	
	_delay_ms(200);
}

void UserPanel::downMelody() // Melodi til at afspille n�r der skrues ned for temperaturen
{
	tonePlayer(392, 300);
	
	tonePlayer(349, 300);
	
	tonePlayer(330, 300);
	
	tonePlayer(294, 300);
	
	tonePlayer(261, 300);
	
	_delay_ms(200);
}

float UserPanel::GetTargetTemp()
{
	return targetTemperature;
}




