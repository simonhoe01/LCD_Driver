/*
 * TemperatureController.h
 *
 * Created: 4/21/2024 2:34:33 PM
 *  Author: simonhoe
 */ 

#ifndef TEMPERATURE_CONTROLLER_H
#define TEMPERATURE_CONTROLLER_H

#include <avr/io.h>
#define F_CPU 16000000
#include <util/delay.h>
#include <stdio.h> // Inklud�r stdio.h-headeren til sprintf
#include "I2CMasterDriver.h"
#include "avr/interrupt.h"



class UserPanel {
public:
    UserPanel();
    void setup();
	void TempUp();
	void TempDown();


private:
    static const uint8_t I2C_WRITE_MODE = 0;
    static const uint8_t DISPLAY_ADDRESS1 = 0x72;

    I2CMaster master;
    float targetTemperature;
    const int buttonPinplus;
    const int buttonPinminus;
    
    void i2cSendValue(int value);
    void tonePlayer(int toneDelay, uint32_t duration);
	void upMelody();
	void downMelody();
	float GetTargetTemp();
};


#endif // TEMPERATURE_CONTROLLER_H
