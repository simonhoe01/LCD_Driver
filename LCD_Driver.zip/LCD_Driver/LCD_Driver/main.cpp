#include "Interrupts.h"
#include "avr/interrupt.h"


int main() {
	
	panelDriver.setup();
	while(1){
		
	}
}


